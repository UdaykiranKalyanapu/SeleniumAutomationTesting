package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Passenger_PO 
{
    public WebDriver driver;
    
    By firstName = By.id("firstName");
    By lastName = By.id("lastName");
    By Mobile = By.id("mobileNumber");
    By Emailaddress = By.id("emailAddress");
    
    
    By firstName2 = By.cssSelector(".bg-light:nth-child(3) > #passenger_form #firstName");
    By lastName2 = By.cssSelector(".bg-light:nth-child(3) > #passenger_form #lastName");
    By Mobile2 = By.cssSelector(".bg-light:nth-child(3) > #passenger_form #mobileNumber");
    By Emailaddress2 = By.cssSelector(".bg-light:nth-child(3) > #passenger_form #emailAddress");
    
    By Button = By.cssSelector(".btn");
    
    public Passenger_PO(WebDriver driver)
    {
    	this.driver = driver;
    }
    
    public WebElement getfirstname()
    {
    	return driver.findElement(firstName);
    }
    
    public WebElement getlastname()
    {
    	return driver.findElement(lastName);
    }
    
    public WebElement getMobile()
    {
    	return driver.findElement(Mobile);
    }
    
    public WebElement getemail()
    {
    	return driver.findElement(Emailaddress);
    }
    public WebElement getfirstname2()
    {
    	return driver.findElement(firstName2);
    }
    
    public WebElement getlastname2()
    {
    	return driver.findElement(lastName2);
    }
    
    public WebElement getMobile2()
    {
    	return driver.findElement(Mobile2);
    }
    
    public WebElement getemail2()
    {
    	return driver.findElement(Emailaddress2);
    }
    
    public WebElement getbutton()
    {
    	return driver.findElement(Button);
    }
}
