package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class PaymentPage_PO 
{
    public WebDriver driver;
    
    By cardnumber = By.id("cardNumber");
    By cardholdername = By.id("cardholderName");
    By exp = By.id("exp");
    By cvc = By.id("cvc");
    By PayButton = By.cssSelector(".btn");
    
    
    
    
    public PaymentPage_PO(WebDriver driver)
    {
    	this.driver = driver;
    }
    
    public WebElement getcardnumber()
    {
    	return driver.findElement(cardnumber);
    }
    
    public WebElement getexp()
    {
    	return driver.findElement(exp);
    }
    
    public WebElement getcvc()
    {
    	return driver.findElement(cvc);
    }
    
    public WebElement getPayButton()
    {
    	return driver.findElement(PayButton);
    }
     public WebElement getcardholdername() {
    	 return driver.findElement(cardholdername);
     }
}
