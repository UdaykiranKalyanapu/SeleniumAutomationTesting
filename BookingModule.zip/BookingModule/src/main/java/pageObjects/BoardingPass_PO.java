package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class BoardingPass_PO 
{
    public WebDriver driver;
    
    By cardnumber = By.id("cardNumber");
    By cardholdername = By.id("cardholderName");
    By exp = By.id("exp");
    By cvc = By.id("cvc");
    By PayButton = By.cssSelector(".btn");
  
    By login_btn = By.linkText("Login");
    By Username = By.id("username");
    By Password = By.id("password");
    By login_btn2 = By.cssSelector(".btn");
    By Origin = By.xpath("/html/body/div[1]/div/div[2]/div/div[1]/form/div[1]/input");
    By Destination = By.xpath("/html/body/div[1]/div/div[2]/div/div[1]/form/div[2]/input");
    By Date = By.xpath("/html/body/div[1]/div/div[2]/div/div[1]/form/div[3]/input");
    By NumberofPassengers = By.xpath("/html/body/div[1]/div/div[2]/div/div[1]/form/div[4]/input");
    By Submit = By.xpath("/html/body/div/div/div[2]/div/div[1]/form/button");
    By AvailableFlight = By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[2]/table/tbody/tr");
    By BookingsTab = By.xpath("/html/body/div/nav/div/div/ul/li[2]/a");
    By PNRText = By.xpath("/html/body/div[1]/div/div[2]/div/div[3]/p[2]");
    By CheckIn = By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[3]/a");
    By PNRField = By.xpath("/html/body/div[1]/div/form/div/input");
    By SearchPNRBTN = By.xpath("/html/body/div/div/form/div/button");
    By FinalCheckIN = By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[5]/button");
    
    public BoardingPass_PO(WebDriver driver)
    {
    	this.driver = driver;
    }
    public WebElement getLoginbutton()
    {
    	return driver.findElement(login_btn);
    }
    
    public WebElement getUsernameField()
    {
    	return driver.findElement(Username);
    }
    
    public WebElement getPasswordField()
    {
    	return driver.findElement(Password);
    }
    
    public WebElement getLoginbutton2()
    {
    	return driver.findElement(login_btn2);
    }
    
    public WebElement getOrigin()
    {
    	return driver.findElement(Origin);
    }
    public WebElement getDestination()
    {
    	return driver.findElement(Destination);
    }
    public WebElement getDate()
    {
    	return driver.findElement(Date);
    }
    public WebElement getNumberofPassengers()
    {
    	return driver.findElement(NumberofPassengers);
    }
    public WebElement getSubmitbutton()
    {
    	return driver.findElement(Submit);
    }
    public WebElement getAvailableFlight()
    {
    	return driver.findElement(AvailableFlight);
    }
    public WebElement getBookingsTab()
    {
    	return driver.findElement(BookingsTab);
    }
    
    
   
    
    public WebElement getcardnumber()
    {
    	return driver.findElement(cardnumber);
    }
    
    public WebElement getexp()
    {
    	return driver.findElement(exp);
    }
    
    public WebElement getcvc()
    {
    	return driver.findElement(cvc);
    }
    
    public WebElement getPayButton()
    {
    	return driver.findElement(PayButton);
    }
     public WebElement getcardholdername() {
    	 return driver.findElement(cardholdername);
     }
     public WebElement getPNRText() {
    	 return driver.findElement(PNRText);
     }
     public WebElement getCheckIN() {
    	 return driver.findElement(CheckIn);
     }
     public WebElement gePNRField() {
    	 return driver.findElement(PNRField);
     }
     public WebElement getSearchPNRBTN() {
    	 return driver.findElement(SearchPNRBTN);
     }
     
     public WebElement getFinalCheckin()
     {
     	return driver.findElement(FinalCheckIN);
     }
}
