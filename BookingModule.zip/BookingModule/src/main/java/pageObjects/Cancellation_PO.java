package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Cancellation_PO 
{
	public WebDriver driver;
    
    By BookingsTab = By.xpath("/html/body/div/nav/div/div/ul/li[2]/a");
    By BookingsInfo = By.xpath("/html/body/div[1]/div/div[2]/div/div[1]/h5[1]");
    By cancelbookingBtn = By.xpath("/html/body/div/div/div[2]/div/div[6]/button");
    By cancelconfirmBtn = By.cssSelector("button:nth-child(1)");
    By cancelInfo = By.xpath("/html/body/div[2]/div/div/div");
    By PayButton = By.cssSelector(".btn");
    By NoBookingInfo = By.xpath("/html/body/div[1]/div/div[2]/p");
    
    
    
    
    public Cancellation_PO(WebDriver driver)
    {
    	this.driver = driver;
    }
    
    public WebElement getBookingsTab()
    {
    	return driver.findElement(BookingsTab);
    }
    
    public WebElement getBookingsInfo()
    {
    	return driver.findElement(BookingsInfo);
    }
    
    public WebElement getcancelconfirmBtn()
    {
    	return driver.findElement(cancelconfirmBtn);
    }
    public WebElement getcancelbookingBtn()
    {
    	return driver.findElement(cancelbookingBtn);
    }
    public WebElement getNoBookingInfo()
    {
    	return driver.findElement(NoBookingInfo);
    }
    
    
    public WebElement getcancelInfo()
    {
    	return driver.findElement(cancelInfo);
    }
     
}
