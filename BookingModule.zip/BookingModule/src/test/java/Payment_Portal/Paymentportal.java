package Payment_Portal;

import static org.junit.Assert.assertThat;

import java.io.IOException;

import org.junit.AfterClass;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import junit.framework.Assert;
import pageObjects.Passenger_PO;
import pageObjects.PaymentPage_PO;
import pageObjects.NavBookingPage_PO;
import resource.Utility;
import resource.base;

@SuppressWarnings("deprecation")



public class Paymentportal{
	
	WebDriver driver;
	String org_name="";
	base bs = new base();
	@Parameters("browser")
	@Test(priority = 1)
	@Given("user is on Payment Page")
	public void user_is_on_PaymentPage(String browser) throws IOException, InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		driver = bs.initializeDriver(browser);
		 driver.get("http://localhost:3000/");
		    driver.manage().window().setSize(new Dimension(1296, 688));
		    NavBookingPage_PO nav = new NavBookingPage_PO(driver);
		    nav.getLoginbutton().click();
		  
		    Thread.sleep(3000);
		    nav.getUsernameField().click();	   		
		    Thread.sleep(3000);
		    nav.getUsernameField().sendKeys("kal@gmail.com");		
		    nav.getPasswordField().click();		
		    Thread.sleep(3000);
		    nav.getPasswordField().sendKeys("123412341234");		
		    Thread.sleep(3000);
		    nav.getLoginbutton2().click();
		
		    Thread.sleep(3000);
		    
		    
		    nav.getOrigin().sendKeys("mumbai");
			Thread.sleep(2000);
			nav.getDestination().sendKeys("delhi");
			Thread.sleep(2000);
			nav.getDate().sendKeys("17032023");
			Thread.sleep(2000);
			nav.getNumberofPassengers().sendKeys("2");
			Thread.sleep(2000);
			nav.getSubmitbutton().click();
			driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div[2]/table/tbody/tr")).click();
			
			Passenger_PO pas = new Passenger_PO(driver);
			pas.getfirstname().click();
			pas.getfirstname().sendKeys("uday");
			pas.getlastname().click();
			pas.getlastname().sendKeys("k");
			pas.getMobile().click();
			pas.getMobile().sendKeys("9848022338");
			pas.getemail().click();
			pas.getemail().sendKeys("kal@gmail.com");
			pas.getfirstname2().click();
			pas.getfirstname2().sendKeys("kiran");
			pas.getlastname2().click();
			pas.getlastname2().sendKeys("U");
			pas.getMobile2().click();
			pas.getMobile2().sendKeys("8297719888");
			pas.getemail2().click();
			pas.getemail2().sendKeys("uday@gmail.com");
			pas.getbutton().click();
	}
	
	@Test(priority = 2)
	@When("user enters Payment credentials")
	public void user_enters_Payment_credentials() throws InterruptedException {
		
		 PaymentPage_PO pp = new PaymentPage_PO(driver);
		pp.getcardnumber().sendKeys("1234123412341234");
	   pp.getcardholdername().sendKeys("udayk");
	    pp.getexp().sendKeys("11/2023");
	  pp.getcvc().sendKeys("111");
	    
	   
	 
	}
	@Test(priority = 3)
	@And("user clicks on pay button")
	public void clicks_pay_button() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		 PaymentPage_PO pp = new PaymentPage_PO(driver);
		 pp.getPayButton().click();
	
	//driver.findElement(By.cssSelector(".btn")).click();
		
		
		// driver.findElement(By.cssSelector(".btn")).click();
	}
	
	@SuppressWarnings("deprecation")
	@Test(priority = 4)
	@Then("user is displayed with a message of successful booking")
	public void displayed_with_thankyou_message() throws InterruptedException {
		Thread.sleep(4000);
		
		String Expected_Text = driver.findElement(By.cssSelector(".success-title")).getText();
		
		   
		    Assert.assertEquals(bs.paymentsuccessful, Expected_Text);
		System.out.println("User has done a successful booking");
		String Expected_Text2 = driver.findElement(By.cssSelector(".complement")).getText();
		  Assert.assertEquals(bs.thankyoumsg, Expected_Text2);
		 System.out.println("User has been displayed with a thank you message");
		// driver.close();
		 System.out.println("PaymentPortal");
			Utility.captureScreenshot(driver, "PaymentPage");
			
			Thread.sleep(3000);
			driver.close();
	}
	@AfterClass
	public void after_class() {
		Utility.captureScreenshot(driver, "PaymentPage");
	}

	}
	
