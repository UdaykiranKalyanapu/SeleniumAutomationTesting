package Navigation_to_booking_page;

import java.io.IOException;

import org.junit.AfterClass;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import io.cucumber.java.AfterAll;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import junit.framework.Assert;
import pageObjects.Passenger_PO;
import pageObjects.NavBookingPage_PO;
import resource.Utility;
import resource.base;

public class NavigationToBookingPage{
	WebDriver driver;
	base bs = new base();
	private String Expected_Title;
	
	@Parameters("browser")
	@Test(priority = 1)
	@Given("user is on search page")
	public void user_is_on_search_page(String browser) throws InterruptedException, IOException {
	    // Write code here that turns the phrase above into concrete actions
		
		driver = bs.initializeDriver(browser);
		 driver.get("http://localhost:3000/");
		    driver.manage().window().setSize(new Dimension(1296, 688));
		    NavBookingPage_PO nav = new NavBookingPage_PO(driver);
		    nav.getLoginbutton().click();
		  
		    Thread.sleep(3000);
		    nav.getUsernameField().click();	   		
		    Thread.sleep(3000);
		    nav.getUsernameField().sendKeys("kal@gmail.com");		
		    nav.getPasswordField().click();		
		    Thread.sleep(3000);
		    nav.getPasswordField().sendKeys("123412341234");		
		    Thread.sleep(3000);
		    nav.getLoginbutton2().click();
		
		    Thread.sleep(3000);
		//driver.findElement(By.linkText("Login")).click();
	    //driver.findElement(By.id("username")).click();
		//driver.findElement(By.id("username")).sendKeys("kal@gmail.com");
		//driver.findElement(By.id("password")).click();
		//driver.findElement(By.id("password")).sendKeys("123412341234");
		//driver.findElement(By.cssSelector(".btn")).click();
		// driver.findElement(By.linkText("Bookings")).click();
	}
	
	@Test(priority = 2)
	@When("user searches for available flights")
	public void user_searches_for_available_flights() throws InterruptedException {
		NavBookingPage_PO nav = new NavBookingPage_PO(driver);
		/* nav.getOrigin().click();
		nav.getOrigin().sendKeys("mumbai");
		Thread.sleep(2000);
driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[1]/form/div[2]/i")).click();
		nav.getDestination().click();
		nav.getDestination().sendKeys("delhi");
		Thread.sleep(2000); */
		
		
		nav.getOrigin().sendKeys("mumbai");
		Thread.sleep(2000);
		nav.getDestination().sendKeys("delhi");
		Thread.sleep(2000);
		nav.getDate().sendKeys("17032023");
		Thread.sleep(2000);
		nav.getNumberofPassengers().sendKeys("2");
		Thread.sleep(2000);
		nav.getSubmitbutton().click();
		
		
		/*
	   driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div[1]/form/div[1]/input")).sendKeys("mumbai");
	   driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div[1]/form/div[2]/input")).sendKeys("delhi");
	   driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div[1]/form/div[3]/input")).sendKeys("17032023");
	   driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div[1]/form/div[4]/input")).sendKeys("2");
	   driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div[1]/form/button")).click();
	   
		*/
	}
	
	@Test(priority = 3)
	@Then("user clicks on available flight booking")
	public void user_clicks_on_available_flight_bookings() throws InterruptedException {
		NavBookingPage_PO nav = new NavBookingPage_PO(driver);
		nav.getAvailableFlight().click();
		
	   //driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[2]/table/tbody/tr")).click();
	}
	
	@Test(priority = 4)
	@And("user is navigated to Booking Page")
	public void user_is_navigated_to_booking_page() throws InterruptedException {
		NavBookingPage_PO nav = new NavBookingPage_PO(driver);
		String Expected_Text = driver.findElement(By.xpath("/html/body/div/div/div[2]/div[1]/h5")).getText();
		
		Assert.assertEquals(bs.Booking_Page_text, Expected_Text);
		System.out.println("User is in Booking Page");
		System.out.println("NavigationToBookingPage");
		
		Utility.captureScreenshot(driver, "NavigationPage");
		Thread.sleep(3000);
		driver.close();
	}
	@org.testng.annotations.AfterClass
	public void after_class() {
		Utility.captureScreenshot(driver, "NavigationPage");
	}
}