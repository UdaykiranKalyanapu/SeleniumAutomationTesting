package PNR_Check;

import static org.junit.Assert.assertThat;

import java.io.IOException;

import org.junit.AfterClass;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import junit.framework.Assert;
import pageObjects.Passenger_PO;
import pageObjects.PaymentPage_PO;
import pageObjects.NavBookingPage_PO;
import pageObjects.PNRCheck_PO;
import resource.Utility;
import resource.base;

@SuppressWarnings("deprecation")



public class PNR_Check{
	public String PNRnumber = "";
	WebDriver driver;
	String org_name="";
	base bs = new base();
	@Parameters("browser")
	@Test(priority = 1)
	@Given("I am in Home Page")
	public void user_is_on_HomePage(String browser) throws IOException, InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		driver = bs.initializeDriver(browser);
		 driver.get("http://localhost:3000/");
		    driver.manage().window().setSize(new Dimension(1296, 688));
		    PNRCheck_PO PNR = new PNRCheck_PO(driver);
		    PNR.getLoginbutton().click();
		  
		    Thread.sleep(3000);
		    PNR.getUsernameField().click();	   		
		    Thread.sleep(3000);
		    PNR.getUsernameField().sendKeys("kal34@gmail.com");		
		    PNR.getPasswordField().click();		
		    Thread.sleep(3000);
		    PNR.getPasswordField().sendKeys("123412341234");		
		    Thread.sleep(3000);
		    PNR.getLoginbutton2().click();
		
		    Thread.sleep(3000);
		    
		    
		    PNR.getOrigin().sendKeys("mumbai");
			Thread.sleep(2000);
			PNR.getDestination().sendKeys("delhi");
			Thread.sleep(2000);
			PNR.getDate().sendKeys("17032023");
			Thread.sleep(2000);
			PNR.getNumberofPassengers().sendKeys("2");
			Thread.sleep(2000);
			PNR.getSubmitbutton().click();
			driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div[2]/table/tbody/tr")).click();
			
			Passenger_PO pas = new Passenger_PO(driver);
			pas.getfirstname().click();
			pas.getfirstname().sendKeys("uday");
			pas.getlastname().click();
			pas.getlastname().sendKeys("k");
			pas.getMobile().click();
			pas.getMobile().sendKeys("9848022338");
			pas.getemail().click();
			pas.getemail().sendKeys("kal@gmail.com");
			pas.getfirstname2().click();
			pas.getfirstname2().sendKeys("kiran");
			pas.getlastname2().click();
			pas.getlastname2().sendKeys("U");
			pas.getMobile2().click();
			pas.getMobile2().sendKeys("8297719888");
			pas.getemail2().click();
			pas.getemail2().sendKeys("uday@gmail.com");
			pas.getbutton().click();
		
			PNR.getcardnumber().sendKeys("1234123412341234");
			PNR.getcardholdername().sendKeys("udayk");
			PNR.getexp().sendKeys("11/2023");
			PNR.getcvc().sendKeys("111");
			PNR.getPayButton().click();
			
		
			
	}
	
	@Test(priority = 2)
	@When("I click on CheckIn Tab")
	public void I_click_on_checkIN_Tab() throws InterruptedException {
		
		  PNRCheck_PO PNR = new PNRCheck_PO(driver);
		Thread.sleep(3000);
		PNR.getCheckIN().click();
		
		
	    
	   
	 
	}
	@Test(priority = 3)
	@And("I enter valid PNR number")
	public void I_enter_valid_PNR_Number() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		
		  PNRCheck_PO PNR = new PNRCheck_PO(driver);
		 PNR.getBookingsTab().click();
		PNRnumber = PNR.getPNRText().getText();
		System.out.println("PNR numer is "+PNRnumber);
		PNR.getCheckIN().click();
		PNR.gePNRField().sendKeys(PNRnumber);
		PNR.getSearchPNRBTN().click();
		
	
	//driver.findElement(By.cssSelector(".btn")).click();
		
		
		// driver.findElement(By.cssSelector(".btn")).click();
	}
	
	@SuppressWarnings("deprecation")
	@Test(priority = 4)
	@Then("I must be displayed with respective ticket information")
	public void displayed_with_repective_ticket() throws InterruptedException {
		Thread.sleep(3000);
		
		String Expected_Text = driver.findElement(By.xpath("/html/body/div/div/div[2]/div/div[1]/h5[1]")).getText();
		
		   
		    Assert.assertEquals(bs.BookingInfo, Expected_Text);
		System.out.println("User is displayed with booked ticket for checkin");
		System.out.println("PNR_CHeck");
		// driver.close();
			Utility.captureScreenshot(driver, "PNRCheck");
			driver.close();
	}
	@AfterClass
	public void after_class() {
		Utility.captureScreenshot(driver, "PNRCheck");
	}

	}
	
