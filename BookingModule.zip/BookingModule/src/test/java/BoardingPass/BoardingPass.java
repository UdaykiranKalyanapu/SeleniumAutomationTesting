package BoardingPass;

import static org.junit.Assert.assertThat;

import java.io.IOException;

import org.junit.AfterClass;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import junit.framework.Assert;
import pageObjects.Passenger_PO;
import pageObjects.PaymentPage_PO;
import pageObjects.BoardingPass_PO;
import pageObjects.NavBookingPage_PO;
import pageObjects.PNRCheck_PO;
import resource.Utility;
import resource.base;

@SuppressWarnings("deprecation")



public class BoardingPass{
	public String PNRnumber = "";
	WebDriver driver;
	String org_name="";
	base bs = new base();
	@Parameters("browser")
	@Test(priority = 1)
	@Given("I am in Home Page")
	public void user_is_on_HomePage(String browser) throws IOException, InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		driver = bs.initializeDriver(browser);
		 driver.get("http://localhost:3000/");
		    driver.manage().window().setSize(new Dimension(1296, 688));
		    BoardingPass_PO BP = new BoardingPass_PO(driver);
		    BP.getLoginbutton().click();
		  
		    Thread.sleep(3000);
		    BP.getUsernameField().click();	   		
		    Thread.sleep(3000);
		    BP.getUsernameField().sendKeys("kal33@gmail.com");		
		    BP.getPasswordField().click();		
		    Thread.sleep(3000);
		    BP.getPasswordField().sendKeys("123412341234");		
		    Thread.sleep(3000);
		    BP.getLoginbutton2().click();
		
		    Thread.sleep(3000);
		    
		    
		    BP.getOrigin().sendKeys("mumbai");
			Thread.sleep(2000);
			BP.getDestination().sendKeys("delhi");
			Thread.sleep(2000);
			BP.getDate().sendKeys("17032023");
			Thread.sleep(2000);
			BP.getNumberofPassengers().sendKeys("2");
			Thread.sleep(2000);
			BP.getSubmitbutton().click();
			driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div[2]/table/tbody/tr")).click();
			
			Passenger_PO pas = new Passenger_PO(driver);
			pas.getfirstname().click();
			pas.getfirstname().sendKeys("uday");
			pas.getlastname().click();
			pas.getlastname().sendKeys("k");
			pas.getMobile().click();
			pas.getMobile().sendKeys("9848022338");
			pas.getemail().click();
			pas.getemail().sendKeys("kal@gmail.com");
			pas.getfirstname2().click();
			pas.getfirstname2().sendKeys("kiran");
			pas.getlastname2().click();
			pas.getlastname2().sendKeys("U");
			pas.getMobile2().click();
			pas.getMobile2().sendKeys("8297719888");
			pas.getemail2().click();
			pas.getemail2().sendKeys("uday@gmail.com");
			pas.getbutton().click();
		
			BP.getcardnumber().sendKeys("1234123412341234");
			BP.getcardholdername().sendKeys("udayk");
			BP.getexp().sendKeys("11/2023");
			BP.getcvc().sendKeys("111");
			BP.getPayButton().click();
			
		
			
	}
	
	@Test(priority = 2)
	@When("I click on CheckIn Tab")
	public void I_click_on_checkIN_Tab() throws InterruptedException {
		
		BoardingPass_PO BP = new BoardingPass_PO(driver);
		Thread.sleep(3000);
		BP.getCheckIN().click();
		
		
	    
	   
	 
	}
	@Test(priority = 3)
	@And("I enter valid PNR number")
	public void I_enter_valid_PNR_Number() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		
		BoardingPass_PO BP = new BoardingPass_PO(driver);
		 BP.getBookingsTab().click();
		PNRnumber = BP.getPNRText().getText();
		System.out.println("PNR numer is "+PNRnumber);
		BP.getCheckIN().click();
		BP.gePNRField().sendKeys(PNRnumber);
		BP.getSearchPNRBTN().click();
		
	
	//driver.findElement(By.cssSelector(".btn")).click();
		
		
		// driver.findElement(By.cssSelector(".btn")).click();
	}
	
	@Test(priority = 4)
	@And("I click on checkIn as passengers")
	public void i_click_on_CheckIn_as_Passengers() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		BoardingPass_PO BP = new BoardingPass_PO(driver);
			BP.getFinalCheckin().click();
			Thread.sleep(1000);
			driver.findElement(By.xpath("/html/body/div[1]/div/div[3]/div/div/div[2]/div/input")).click();
			Thread.sleep(3000);
			driver.findElement(By.xpath("/html/body/div[1]/div/div[3]/div/div/div[3]/button[2]")).click();
	
	//driver.findElement(By.cssSelector(".btn")).click();
		
		
		// driver.findElement(By.cssSelector(".btn")).click();
	}
	@SuppressWarnings("deprecation")
	@Test(priority = 5)
	@Then("I must be CheckIn Successfully")
	public void i_Must_be_CheckedIN_Successfully() throws InterruptedException {
		String Expected_Text = driver.findElement(By.xpath("/html/body/div/div/div/div[1]/div/span[3]")).getText();
	
		   
	    Assert.assertEquals(bs.BoardingText, Expected_Text);
	System.out.println("User is displayed with boardingPass");
		
	System.out.println("boardingPass");
			Utility.captureScreenshot(driver, "BoardingPass");
			driver.close();
	}
	@AfterClass
	public void after_class() {
		Utility.captureScreenshot(driver, "BoardingPass");
		driver.close();
	}

	}
	
