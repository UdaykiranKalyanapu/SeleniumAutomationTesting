package Passengers_details;

import java.io.IOException;

import org.junit.AfterClass;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import junit.framework.Assert;
import pageObjects.Passenger_PO;
import pageObjects.NavBookingPage_PO;
import resource.Utility;
import resource.base;

@SuppressWarnings("deprecation")



public class PassengersDetails{
	
	WebDriver driver;
	String org_name="";
	base bs = new base();
	@Parameters("browser")
	@Test(priority = 1)
	@Given("user is on Booking page")
	public void user_is_on_BookingPage(String browser) throws IOException, InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		driver = bs.initializeDriver(browser);
		 driver.get("http://localhost:3000/");
		    driver.manage().window().setSize(new Dimension(1296, 688));
		    NavBookingPage_PO nav = new NavBookingPage_PO(driver);
		    nav.getLoginbutton().click();
		  
		    Thread.sleep(3000);
		    nav.getUsernameField().click();	   		
		    Thread.sleep(3000);
		    nav.getUsernameField().sendKeys("kal@gmail.com");		
		    nav.getPasswordField().click();		
		    Thread.sleep(3000);
		    nav.getPasswordField().sendKeys("123412341234");		
		    Thread.sleep(3000);
		    nav.getLoginbutton2().click();
		
		    Thread.sleep(3000);
		    
		    
		    nav.getOrigin().sendKeys("mumbai");
			Thread.sleep(2000);
			nav.getDestination().sendKeys("delhi");
			Thread.sleep(2000);
			nav.getDate().sendKeys("17032023");
			Thread.sleep(2000);
			nav.getNumberofPassengers().sendKeys("2");
			Thread.sleep(2000);
			nav.getSubmitbutton().click();
			driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div[2]/table/tbody/tr")).click();
	}
	
	@Test(priority = 2)
	@When("user enters passengers details")
	public void enters_number_and_password() throws InterruptedException {
		Passenger_PO pas = new Passenger_PO(driver);
		pas.getfirstname().click();
		pas.getfirstname().sendKeys("uday");
		pas.getlastname().click();
		pas.getlastname().sendKeys("k");
		pas.getMobile().click();
		pas.getMobile().sendKeys("9848022338");
		pas.getemail().click();
		pas.getemail().sendKeys("kal@gmail.com");
		pas.getfirstname2().click();
		pas.getfirstname2().sendKeys("kiran");
		pas.getlastname2().click();
		pas.getlastname2().sendKeys("U");
		pas.getMobile2().click();
		pas.getMobile2().sendKeys("8297719888");
		pas.getemail2().click();
		pas.getemail2().sendKeys("uday@gmail.com");
		/*driver.findElement(By.id("firstName")).click();
	    driver.findElement(By.id("firstName")).sendKeys("uday");
	    driver.findElement(By.id("lastName")).click();
	    driver.findElement(By.id("lastName")).sendKeys("k");
	    driver.findElement(By.id("mobileNumber")).click();
	    driver.findElement(By.id("mobileNumber")).sendKeys("9848022338");
	    driver.findElement(By.id("emailAddress")).click();
	    driver.findElement(By.id("emailAddress")).sendKeys("kal@gmail.com");
	    driver.findElement(By.cssSelector(".bg-light:nth-child(3) > #passenger_form #firstName")).click();
	    driver.findElement(By.cssSelector(".bg-light:nth-child(3) > #passenger_form #firstName")).sendKeys("kiran");
	    driver.findElement(By.cssSelector(".bg-light:nth-child(3) > #passenger_form #lastName")).click();
	    driver.findElement(By.cssSelector(".bg-light:nth-child(3) > #passenger_form #lastName")).sendKeys("u");
	    driver.findElement(By.cssSelector(".bg-light:nth-child(3) > #passenger_form #mobileNumber")).click();
	    driver.findElement(By.cssSelector(".bg-light:nth-child(3) > #passenger_form #mobileNumber")).sendKeys("8297719888");
	    driver.findElement(By.cssSelector(".bg-light:nth-child(3) > #passenger_form #emailAddress")).click();
	    driver.findElement(By.cssSelector(".bg-light:nth-child(3) > #passenger_form #emailAddress")).sendKeys("uday@gmail.com");
	    */
	 
	}
	@Test(priority = 3)
	@And("user clicks on continue button")
	public void clicks_login_button() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		Passenger_PO pas = new Passenger_PO(driver);
		pas.getbutton().click();
		
		// driver.findElement(By.cssSelector(".btn")).click();
	}
	
	@SuppressWarnings("deprecation")
	@Test(priority = 4)
	@Then("user is navigated to payment portal")
	public void user_is_navigated_to_payment_portal() throws InterruptedException {
		Passenger_PO pas = new Passenger_PO(driver);
		String Expected_Text = driver.findElement(By.xpath("/html/body/div/div/div[2]/div/div/div/p")).getText();
		
		Assert.assertEquals(bs.Payment_Page, Expected_Text);
		System.out.println("User is in payments Page");
		System.out.println("PassengerDetails");
		//driver.close();
		Utility.captureScreenshot(driver, "PassengerDetails");
		Thread.sleep(3000);
		driver.close();
	}
	@AfterClass
	public void after_class() {
		Utility.captureScreenshot(driver, "PassengerDetails");
	}
}