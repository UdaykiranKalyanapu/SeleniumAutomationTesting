Feature: To test the functionalities of Booking Module.



@tag1
Scenario: Navigation to Booking page
  Given user is on search page
 When user searches for available flights
 And user clicks on available flight booking
 Then user is navigated to Booking Page
 
 @tag2
 Scenario: Passengers Details
  Given user is on Booking page
 When user enters passengers details
 And user clicks on continue button
 Then user is navigated to payment portal
 
 @tag3
 Scenario: Payment Details
  Given user is on Payment Page
 When user enters Payment credentials
 And user clicks on pay button
 Then user is displayed with a message of successful booking
  @tag4
 Scenario: Booking Cancellations
  Given user has made a booking
 When user clicks on Bookings
 And user clicks on cancel reservation
 Then user is displayed with a message of successful cancellation
    
   
@tag5
 Scenario: PNR Check
  Given I am in Home Page
 When I click on CheckIn Tab
 And I enter valid PNR number
 Then I must be displayed with respective ticket information
    
 
 @tag6
 Scenario: Boarding Pass
  Given I am in Home Page
 When I click on CheckIn Tab
 And I enter valid PNR number
 And I click on checkIn as passengers
 Then I must be CheckIn Successfully
    